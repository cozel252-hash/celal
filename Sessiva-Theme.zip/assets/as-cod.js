(() => {
  if (customElements.get('as-cod-dialog')) return;

  const money = (minor, currency) => {
    if (!Number.isFinite(minor)) return '';
    try {
      return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: currency || 'TRY' }).format(minor / 100);
    } catch (_) {
      return `${(minor / 100).toLocaleString('tr-TR', { minimumFractionDigits: 2 })} TL`;
    }
  };

  class AsCodDialog extends HTMLElement {
    connectedCallback() {
      if (this.initialized) return;
      this.initialized = true;
      this.form = this.querySelector('[data-cod-form]');
      this.panel = this.querySelector('[role="dialog"]');
      this.success = this.querySelector('[data-cod-success]');
      this.status = this.querySelector('[data-cod-status]');
      this.submit = this.querySelector('[data-cod-submit]');
      this.submitLabel = this.querySelector('[data-cod-submit-label]');
      this.lastTrigger = null;
      this.startedAt = 0;
      this.onDocumentClick = this.onDocumentClick.bind(this);
      this.onKeydown = this.onKeydown.bind(this);
      this.onSubmit = this.onSubmit.bind(this);
      document.addEventListener('click', this.onDocumentClick);
      this.form?.addEventListener('submit', this.onSubmit);
    }

    disconnectedCallback() {
      document.removeEventListener('click', this.onDocumentClick);
      document.removeEventListener('keydown', this.onKeydown);
      this.form?.removeEventListener('submit', this.onSubmit);
    }

    onDocumentClick(event) {
      const opener = event.target.closest('[data-cod-open]');
      if (opener) {
        const target = opener.getAttribute('aria-controls') || opener.dataset.codTarget;
        if (target && target !== this.id) return;
        if (!target && document.querySelector('as-cod-dialog') !== this) return;
        event.preventDefault();
        this.open(opener);
        return;
      }
      if (event.target.closest('[data-cod-close]') && event.target.closest('as-cod-dialog') === this) {
        event.preventDefault();
        this.close();
      }
    }

    open(trigger) {
      this.lastTrigger = trigger;
      this.reset();
      this.fillOrder(trigger);
      this.hidden = false;
      document.body.classList.add('as-cod-open');
      document.addEventListener('keydown', this.onKeydown);
      requestAnimationFrame(() => this.querySelector('input[name="name"]')?.focus());
    }

    close() {
      this.hidden = true;
      document.body.classList.remove('as-cod-open');
      document.removeEventListener('keydown', this.onKeydown);
      this.reset();
      this.lastTrigger?.focus?.();
      this.lastTrigger = null;
    }

    reset() {
      this.form?.reset();
      this.form.hidden = false;
      this.success.hidden = true;
      this.status.textContent = '';
      this.submit.disabled = false;
      this.submitLabel.textContent = 'Siparişi tamamla';
      this.querySelectorAll('[aria-invalid="true"]').forEach((el) => el.removeAttribute('aria-invalid'));
      this.querySelectorAll('[data-error-for]').forEach((el) => { el.textContent = ''; });
      this.startedAt = Date.now();
      const started = this.form?.elements.namedItem('startedAt');
      if (started) started.value = String(this.startedAt);
    }

    selectedBundle(trigger) {
      const owner = trigger.closest('[data-as-product], .as-product, section') || document;
      return owner.querySelector('[data-bundle].is-selected, [data-bundle][aria-pressed="true"], [data-bundle].on');
    }

    fillOrder(trigger) {
      const selected = this.selectedBundle(trigger);
      const get = (name, fallback = '') => trigger.dataset[name] || selected?.dataset?.[name] || fallback;
      const variantId = get('variantId', this.dataset.defaultVariant || '');
      const quantity = Math.max(1, Number.parseInt(get('quantity', '1'), 10) || 1);
      const bundleName = get('bundleName', get('name', this.dataset.productTitle || 'Seçili ürün'));
      const rawPrice = get('bundlePrice', get('price', ''));
      const priceMinor = /^\d+$/.test(rawPrice) ? Number(rawPrice) : NaN;
      const feeMinor = Number(get('codFee', this.dataset.defaultFee || '0'));
      this.form.elements.namedItem('variantId').value = variantId;
      this.form.elements.namedItem('quantity').value = String(quantity);
      this.form.elements.namedItem('bundleName').value = bundleName;
      this.querySelector('[data-cod-summary-name]').textContent = bundleName;
      const summary = this.querySelector('[data-cod-summary-total]');
      if (Number.isFinite(priceMinor)) {
        summary.textContent = money(priceMinor + (Number.isFinite(feeMinor) ? feeMinor : 0), this.dataset.currency);
      } else {
        summary.textContent = feeMinor > 0
          ? `Ürün tutarı + ${money(feeMinor, this.dataset.currency)} kapıda ödeme ücreti`
          : 'Kesin tutar sipariş servisinde hesaplanır';
      }
    }

    onKeydown(event) {
      if (event.key === 'Escape') {
        this.close();
        return;
      }
      if (event.key !== 'Tab') return;
      const focusable = [...this.panel.querySelectorAll('button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')].filter((el) => !el.closest('[hidden]'));
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }

    clearErrors() {
      this.status.textContent = '';
      this.querySelectorAll('[aria-invalid="true"]').forEach((el) => el.removeAttribute('aria-invalid'));
      this.querySelectorAll('[data-error-for]').forEach((el) => { el.textContent = ''; });
    }

    setError(name, message) {
      const field = this.form.elements.namedItem(name);
      field?.setAttribute('aria-invalid', 'true');
      const error = this.querySelector(`[data-error-for="${name}"]`);
      if (error) error.textContent = message;
      return field;
    }

    values() {
      const data = new FormData(this.form);
      return Object.fromEntries(data.entries());
    }

    validate(data) {
      this.clearErrors();
      let first;
      const invalid = (name, message) => { first ||= this.setError(name, message); };
      if (data.name.trim().length < 3) invalid('name', 'Lütfen adınızı ve soyadınızı yazın.');
      const phone = data.phone.replace(/[^\d+]/g, '').replace(/^\+90/, '0').replace(/^90/, '0');
      if (!/^05\d{9}$/.test(phone)) invalid('phone', 'Telefonu 05xx xxx xx xx biçiminde yazın.');
      if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) invalid('email', 'Geçerli bir e-posta adresi yazın.');
      if (!data.il) invalid('il', 'Lütfen ilinizi seçin.');
      if (data.ilce.trim().length < 2) invalid('ilce', 'Lütfen ilçenizi yazın.');
      if (data.address.trim().length < 10) invalid('address', 'Açık adresinizi en az 10 karakterle yazın.');
      if (!data.variantId) {
        this.status.textContent = 'Ürün varyantı belirlenemedi. Sayfayı yenileyip tekrar deneyin.';
        first ||= this.submit;
      }
      first?.focus?.();
      return !first;
    }

    async onSubmit(event) {
      event.preventDefault();
      const data = this.values();
      if (!this.validate(data)) return;
      data.quantity = Number.parseInt(data.quantity, 10) || 1;
      data.startedAt = Number.parseInt(data.startedAt, 10) || this.startedAt;
      const province = this.form.elements.namedItem('il');
      data.province = province?.selectedOptions?.[0]?.textContent || '';
      this.submit.disabled = true;
      this.submitLabel.textContent = 'Sipariş oluşturuluyor…';
      this.status.textContent = '';

      try {
        const response = await fetch(this.dataset.endpoint || '/apps/kapida-odeme', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify(data),
        });
        const text = await response.text();
        let result = {};
        try { result = text ? JSON.parse(text) : {}; } catch (_) { result = {}; }
        if (!response.ok || result.ok !== true) {
          throw new Error(result.error || result.detail || 'Sipariş şu anda oluşturulamadı. Lütfen tekrar deneyin.');
        }
        this.form.reset();
        this.form.hidden = true;
        this.success.hidden = false;
        this.success.focus();
      } catch (error) {
        this.status.textContent = error?.message || 'Bağlantı kurulamadı. Lütfen kısa bir süre sonra tekrar deneyin.';
        this.submit.disabled = false;
        this.submitLabel.textContent = 'Tekrar dene';
      }
    }
  }

  customElements.define('as-cod-dialog', AsCodDialog);
})();
