(() => {
  if (window.__sessivaThemeLoaded) return;
  window.__sessivaThemeLoaded = true;

  const ready = (fn) => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once: true });
    else fn();
  };

  const money = (cents) => new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY',
    minimumFractionDigits: 2,
  }).format(Number(cents || 0) / 100);

  const addDays = (count) => {
    const date = new Date();
    date.setDate(date.getDate() + Number(count || 0));
    return date;
  };

  const dateLabel = (date) => date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' });

  window.Sessiva = Object.freeze({ money, addDays, dateLabel, ready });

  ready(() => {
    document.documentElement.classList.add('sessiva-ready');
    document.querySelectorAll('[data-as-date]').forEach((node) => {
      const values = String(node.dataset.asDate || '').split('-').map(Number).filter(Number.isFinite);
      if (!values.length) return;
      node.textContent = values.length > 1
        ? dateLabel(addDays(values[0])) + ' – ' + dateLabel(addDays(values[1]))
        : dateLabel(addDays(values[0]));
    });
  });
})();
